// Entry point will be added in a Next.js environment setup
// You can place your TrainingApp component here or create pages/index.js
